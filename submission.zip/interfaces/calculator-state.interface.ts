
import { OperatorKeys } from '../enums/operator-keys.enum';

export interface ICalculatorState {
  digit(digit: string): void;
  decimalSeparator(): void;
  binaryOperator(operator: OperatorKeys): ICalculatorState;
  equals(): ICalculatorState;
  clear(): ICalculatorState;
  display(): string;
}
