
import { OperatorKeys } from '../enums/operator-keys.enum';
import { ICalculatorState } from '../interfaces/calculator-state.interface';
import { EnteringSecondNumberState } from './entering-second-number.state';

export class EnteringFirstNumberState implements ICalculatorState {

  public constructor(private _buffer: string) { }

  public digit(digit: string): void {
    this._buffer = this._buffer === '0' && digit !== '0' ? digit : this._buffer + digit;
  }

  public decimalSeparator(): void {
    if (this._buffer.indexOf('.') === -1) {
      // ignore if the number already has a decimal separator
      this._buffer = this._buffer + '.';
    }
  }

  public binaryOperator(operator: OperatorKeys): ICalculatorState {
    return new EnteringSecondNumberState(this._buffer === '' ? '0' : this._buffer, '', operator);
  }

  public equals(): ICalculatorState {
    /* pressing equals after entering one number has no effect */
    return this;
  }

  public clear(): ICalculatorState {
    return new EnteringFirstNumberState('');
  }

  public display(): string {
    return this._buffer;
  }

}
