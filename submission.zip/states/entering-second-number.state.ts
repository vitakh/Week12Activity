
import { OperatorKeys } from '../enums/operator-keys.enum';
import { ICalculatorState } from '../interfaces/calculator-state.interface';
import { EnteringFirstNumberState } from './entering-first-number.state';
import { EnteringThirdNumberState } from './entering-third-number.state';
import { ErrorState } from './error.state';

export class EnteringSecondNumberState implements ICalculatorState {

  public constructor(
    private firstBuffer: string,
    private secondBuffer: string,
    private firstOperator: OperatorKeys
  ) { }

  public digit(digit: string): void {
    this.secondBuffer = (this.secondBuffer === '0' && digit !== '0') ? digit : this.secondBuffer + digit;
  }

  public decimalSeparator(): void {
    if (this.secondBuffer.indexOf('.') === -1){ // ignore if the number already has a decimal separator
      this.secondBuffer = this.secondBuffer + '.';
    }
  }

  public binaryOperator(operator: OperatorKeys): ICalculatorState {
    const firstNumber: number = parseFloat(this.firstBuffer === '' ? '0' : this.firstBuffer);
    const secondNumber: number = parseFloat(this.secondBuffer === '' ? '0' : this.secondBuffer);
    let newState: ICalculatorState = new ErrorState();

    switch (operator){
      case OperatorKeys.PLUS:   // in case of + or - after having entered two numbers, apply the first operator and stay in this state
      case OperatorKeys.MINUS:  // (or go to ErrorState in case of division by zero)
        if (this.firstOperator === OperatorKeys.PLUS){
          this.firstBuffer = (firstNumber + secondNumber).toString();
        } else if (this.firstOperator === OperatorKeys.MINUS){
          this.firstBuffer = (firstNumber - secondNumber).toString();
        } else if (this.firstOperator === OperatorKeys.MULT){
          this.firstBuffer = (firstNumber * secondNumber).toString();
        } else if (secondNumber !== 0){ // (this.firstOperator === OperatorKeys.DIV){
          this.firstBuffer = (firstNumber / secondNumber).toString();
        } else {
          newState = new ErrorState();
        }
        this.secondBuffer = '';
        this.firstOperator = operator;
        break;
      case OperatorKeys.DIV: // if we press * or / after having entered two numbers
      case OperatorKeys.MULT:
        if (this.firstOperator === OperatorKeys.MULT){ // If the first operator was *, apply it
          this.firstBuffer = (firstNumber * secondNumber).toString();
          this.secondBuffer = '';
          this.firstOperator = operator;
        } else if (this.firstOperator === OperatorKeys.DIV){ // If the first operator was /, apply it
          if (secondNumber === 0){ // check for div by zero
            newState = new ErrorState();
          } else {
            this.firstBuffer = (firstNumber / secondNumber).toString();
            this.secondBuffer = '';
            this.firstOperator = operator;
          }
        } else { // If the first operator was + or -, transition to EnteringThirdNumberState
          newState = new EnteringThirdNumberState(this.firstBuffer, this.secondBuffer, '', this.firstOperator, operator);
        }
        break;
      default:
        throw new Error('Invalid Operator');
    }

    return newState;

  }

  public equals(): ICalculatorState {
    const firstNumber: number = parseFloat(this.firstBuffer === '' ? '0' : this.firstBuffer);
    const secondNumber: number = parseFloat(this.secondBuffer === '' ? '0' : this.secondBuffer);
    let newState: ICalculatorState;

    if (this.firstOperator === OperatorKeys.PLUS){
      newState = new EnteringFirstNumberState((firstNumber + secondNumber).toString());
    } else if (this.firstOperator === OperatorKeys.MINUS){
      newState = new EnteringFirstNumberState((firstNumber - secondNumber).toString());
    } else if (this.firstOperator === OperatorKeys.MULT){
      newState = new EnteringFirstNumberState((firstNumber * secondNumber).toString());
    } else if (secondNumber !== 0){  // this.firstOperator === OperatorKeys.DIV
      newState = new EnteringFirstNumberState((firstNumber / secondNumber).toString());
    } else {
      newState = new ErrorState();
    }

    return newState;

  }

  public clear(): ICalculatorState {
    return new EnteringFirstNumberState('0');
  }

  public display(): string {
    return (this.secondBuffer !== '') ? this.secondBuffer : this.firstBuffer;
  }

}
