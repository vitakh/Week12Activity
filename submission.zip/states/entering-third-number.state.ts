import { OperatorKeys } from '../enums/operator-keys.enum';
import { ICalculatorState } from '../interfaces/calculator-state.interface';
import { EnteringFirstNumberState } from './entering-first-number.state';
import { EnteringSecondNumberState } from './entering-second-number.state';
import { ErrorState } from './error.state';

export class EnteringThirdNumberState implements ICalculatorState {
  public constructor(
    private firstBuffer: string,
    private secondBuffer: string,
    private thirdBuffer: string,
    private firstOperator: OperatorKeys,
    private secondOperator: OperatorKeys
  ) { }

  public digit(digit: string): void {
    this.thirdBuffer = this.thirdBuffer === '0' && digit !== '0' ? digit : this.thirdBuffer + digit;
  }

  public decimalSeparator(): void {
    if (this.thirdBuffer.indexOf('.') === -1) {
      // ignore if the number already has a decimal separator
      this.thirdBuffer = this.thirdBuffer + '.';
    }
  }

  public binaryOperator(operator: OperatorKeys): ICalculatorState {
    // evaluate the entire expression and transition to EnteringSecondNumberState
    // (or ErrorState in case of division by zero)
    const firstNumber: number = parseFloat(this.firstBuffer === '' ? '0' : this.firstBuffer);
    const secondNumber: number = parseFloat(this.secondBuffer === '' ? '0' : this.secondBuffer);
    const thirdNumber: number = parseFloat(this.thirdBuffer === '' ? '0' : this.thirdBuffer);

    let newState: ICalculatorState = new ErrorState();

    if (operator === OperatorKeys.MULT) {
      const result: number = secondNumber * thirdNumber;
      this.secondBuffer = result.toString();
      this.thirdBuffer = '';
    } else if (operator === OperatorKeys.DIV) {
      if (thirdNumber === 0) {
        newState = new ErrorState();
      } else {
        const result: number = secondNumber / thirdNumber;
        this.secondBuffer = result.toString();
        this.thirdBuffer = '';
      }
    } else if (operator === OperatorKeys.PLUS || operator === OperatorKeys.MINUS) {
      if (this.secondOperator === OperatorKeys.MULT) {
        let result: number = secondNumber * thirdNumber;
        if (this.firstOperator === OperatorKeys.PLUS) {
          result = firstNumber + result;
        } else {
          // (this.firstOperator === OperatorKeys.MINUS)
          result = firstNumber - result;
        }
        newState = new EnteringSecondNumberState(result.toString(), '', operator);
      } else {
        // (this.secondOperator === OperatorKeys.DIV)
        if (thirdNumber !== 0) {
          let result: number = secondNumber / thirdNumber;
          if (this.firstOperator === OperatorKeys.PLUS) {
            result = firstNumber + result;
          } else {
            // (this.firstOperator === OperatorKeys.MINUS)
            result = firstNumber - result;
          }
          newState = new EnteringSecondNumberState(result.toString(), '', operator);
        } else {
          newState = new ErrorState();
        }
      }
    }

    return newState;

  }

  public equals(): ICalculatorState {
    // evaluate the entire expression and transition to EnteringFirstNumberState
    // (or ErrorState in case of division by zero)
    const firstNumber: number = parseFloat(this.firstBuffer === '' ? '0' : this.firstBuffer);
    const secondNumber: number = parseFloat(this.secondBuffer === '' ? '0' : this.secondBuffer);
    const thirdNumber: number = parseFloat(this.thirdBuffer === '' ? '0' : this.thirdBuffer);
    let result: number;
    let newState: ICalculatorState;

    if (this.secondOperator === OperatorKeys.MULT) {
      result = secondNumber * thirdNumber;
    } else {
      // (this.secondOperator === OperatorKeys.DIV)
      if (thirdNumber === 0) {
        newState = new ErrorState();
        return newState;
      } else {
        result = secondNumber / thirdNumber;
      }
    }
    if (this.firstOperator === OperatorKeys.PLUS) {
      newState = new EnteringFirstNumberState((firstNumber + result).toString());
    } else {
      // (this.firstOperator === OperatorKeys.MINUS)
      newState = new EnteringFirstNumberState((firstNumber - result).toString());
    }

    return newState;

  }

  public clear(): ICalculatorState {
    return new EnteringFirstNumberState('');
  }

  public display(): string {
    return this.thirdBuffer !== ''
      ? this.thirdBuffer
      : this.secondBuffer !== ''
        ? this.secondBuffer
        : '0';
  }
}
