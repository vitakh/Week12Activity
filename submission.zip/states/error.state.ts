
import { ICalculatorState } from '../interfaces/calculator-state.interface';
import { EnteringFirstNumberState } from './entering-first-number.state';

// in the ErrorState, pressing "C" will reset the calculator to its original state; other keys have no effect
export class ErrorState implements ICalculatorState {

  public digit(): void { /* nothing */ }

  public decimalSeparator(): void { /* nothing */ }

  public binaryOperator(): ICalculatorState {
    return new ErrorState();
  }

  public equals(): ICalculatorState {
    return new ErrorState();
  }

  public clear(): ICalculatorState {
    return new EnteringFirstNumberState('');
  }

  public display(): string {
    return 'ERR';
  }

}
